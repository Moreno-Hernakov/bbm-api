<?php

use App\Models\MerkKendaraan;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('komposisis', function (Blueprint $table) {
            $table->id();
            $table->integer('jumlah_konsumsi_bbm');
            $table->integer('jarak_tempuh');
            $table->integer('jumlah_uang');
            $table->string('gambar');
            $table->string('gambar_kwitansi');
            $table->integer('kd_jenis_kendaraan');
            $table->foreign('kd_jenis_kendaraan')->references('kd_jenis_kendaraan')->on('jenis_kendaraans')->onDelete('cascade');   $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('komposisis');
    }
};
